-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2020 at 07:30 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `realestate`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `Client_id` int(11) NOT NULL,
  `Client_name` varchar(100) NOT NULL,
  `Client_id_no` int(100) NOT NULL,
  `Client_phone_no` int(20) NOT NULL,
  `Client_Email` varchar(100) NOT NULL,
  `Client_DOB` date NOT NULL,
  `Client_address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`Client_id`, `Client_name`, `Client_id_no`, `Client_phone_no`, `Client_Email`, `Client_DOB`, `Client_address`) VALUES
(2, 'joeBrian', 554466, 75576567, 'joe@gmail', '2020-12-09', '33333');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `Department_id` int(11) NOT NULL,
  `Department_name` varchar(100) NOT NULL,
  `Department_desc` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`Department_id`, `Department_name`, `Department_desc`) VALUES
(90033, 'Client Management', 'add of clients '),
(90034, 'Property Management', 'property '),
(90035, 'ADMIN', 'SYSTEM MANAGEMENT'),
(90041, 'ACCOUNTS', 'RECIEPTING');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Employee_id` int(11) NOT NULL,
  `Employee_name` varchar(100) NOT NULL,
  `Employee_id_no` int(50) NOT NULL,
  `Employee_phone_no` int(20) NOT NULL,
  `Employee_Email` varchar(100) NOT NULL,
  `Employee_department_id` int(50) NOT NULL,
  `Employee_DOB` date NOT NULL,
  `Employee_Address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_id`, `Employee_name`, `Employee_id_no`, `Employee_phone_no`, `Employee_Email`, `Employee_department_id`, `Employee_DOB`, `Employee_Address`) VALUES
(1, 'Mary Njoroge', 20689348, 720946796, 'mary@gmail', 90033, '0000-00-00', '');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `Invoice_id` int(11) NOT NULL,
  `Invoice_no` varchar(100) NOT NULL,
  `Invoice_Amount_to_pay` int(200) NOT NULL,
  `Invoice_Property_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`Invoice_id`, `Invoice_no`, `Invoice_Amount_to_pay`, `Invoice_Property_id`) VALUES
(1, '675656', 600000, 1),
(2, '778787', 900000, 2),
(5, '675656', 600000, 3),
(7, '8799', 10000, 4),
(8, '65656', 100000, 5),
(12, '675656', 600000, 6);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Login_id` int(11) NOT NULL,
  `Login_name` varchar(11) NOT NULL,
  `Login_password` int(11) NOT NULL,
  `Login_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Login_id`, `Login_name`, `Login_password`, `Login_type`) VALUES
(1, 'mary njorog', 2337, 'Admin'),
(2, 'peter devis', 6666, 'PropertyMa'),
(3, 'JoeBrian', 7777, 'Accounts'),
(4, 'dan mwaura', 3333, 'FrontOffice'),
(9, 'Ann', 4444, 'FrontOffice');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `Property_id` int(11) NOT NULL,
  `Property_name` varchar(100) NOT NULL,
  `Property_location` varchar(100) NOT NULL,
  `Property_Askingprice` int(100) NOT NULL,
  `Property_Property_type_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`Property_id`, `Property_name`, `Property_location`, `Property_Askingprice`, `Property_Property_type_id`) VALUES
(1, 'zuma-1bedroom', 'thika', 1000000, 4010),
(2, 'zuma_2bedroom', 'thika', 1000000, 4041),
(3, 'zuma_plot', 'thika', 300000, 4012),
(4, 'thindegua', 'kiambu', 40000, 4011);

-- --------------------------------------------------------

--
-- Table structure for table `property_sale`
--

CREATE TABLE `property_sale` (
  `Property_sale_id` int(11) NOT NULL,
  `Property_sale_Property_id` int(100) NOT NULL,
  `Property_sale_Client_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `property_sale`
--

INSERT INTO `property_sale` (`Property_sale_id`, `Property_sale_Property_id`, `Property_sale_Client_id`) VALUES
(2, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `property_type`
--

CREATE TABLE `property_type` (
  `Property_type_id` int(11) NOT NULL,
  `Property_type_name` varchar(100) NOT NULL,
  `Property_type_desc` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `property_type`
--

INSERT INTO `property_type` (`Property_type_id`, `Property_type_name`, `Property_type_desc`) VALUES
(4010, 'flats', 'one bedroom flats'),
(4011, 'apartment', 'two-bedroom apartment'),
(4013, 'bungalows', 'family house');

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE `receipt` (
  `Receipt_id` int(11) NOT NULL,
  `Receipt_no` varchar(11) NOT NULL,
  `Receipt_Invoice_id` int(11) NOT NULL,
  `Receipt_amount_paid` int(11) NOT NULL,
  `Receipt_payment_mode` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `receipt`
--

INSERT INTO `receipt` (`Receipt_id`, `Receipt_no`, `Receipt_Invoice_id`, `Receipt_amount_paid`, `Receipt_payment_mode`) VALUES
(1, '707070', 1, 100000, 'cash'),
(5, '707070', 2, 100000, '100000'),
(7, '7070000', 8, 800080, '800080');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`Client_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`Department_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_id`),
  ADD UNIQUE KEY `Employee_department_id` (`Employee_department_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`Invoice_id`),
  ADD UNIQUE KEY `Invoice_Property_id` (`Invoice_Property_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Login_id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`Property_id`),
  ADD UNIQUE KEY `Property_Property_type_id` (`Property_Property_type_id`);

--
-- Indexes for table `property_sale`
--
ALTER TABLE `property_sale`
  ADD PRIMARY KEY (`Property_sale_id`),
  ADD UNIQUE KEY `Property_sale_Property_id` (`Property_sale_Property_id`),
  ADD UNIQUE KEY `Property_sale_Client_id` (`Property_sale_Client_id`);

--
-- Indexes for table `property_type`
--
ALTER TABLE `property_type`
  ADD PRIMARY KEY (`Property_type_id`);

--
-- Indexes for table `receipt`
--
ALTER TABLE `receipt`
  ADD PRIMARY KEY (`Receipt_id`),
  ADD UNIQUE KEY `Receipt_Invoice_id` (`Receipt_Invoice_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `Client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `Department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90042;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `Employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `Invoice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `Login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `Property_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `property_sale`
--
ALTER TABLE `property_sale`
  MODIFY `Property_sale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `property_type`
--
ALTER TABLE `property_type`
  MODIFY `Property_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4018;

--
-- AUTO_INCREMENT for table `receipt`
--
ALTER TABLE `receipt`
  MODIFY `Receipt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`Employee_department_id`) REFERENCES `department` (`Department_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `property_sale`
--
ALTER TABLE `property_sale`
  ADD CONSTRAINT `property_sale_ibfk_1` FOREIGN KEY (`Property_sale_Client_id`) REFERENCES `client` (`Client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `property_sale_ibfk_2` FOREIGN KEY (`Property_sale_Property_id`) REFERENCES `property` (`Property_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `receipt`
--
ALTER TABLE `receipt`
  ADD CONSTRAINT `receipt_ibfk_1` FOREIGN KEY (`Receipt_Invoice_id`) REFERENCES `invoice` (`Invoice_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
